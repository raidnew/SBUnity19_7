﻿public interface IItemContainer: IAmUsable
{
    public UsersItems UserItem { get; }
}
