﻿public enum UsersItems
{
    Boots, Pants, Shirt, Sword
}

