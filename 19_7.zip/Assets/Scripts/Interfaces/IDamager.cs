﻿public interface IDamager
{
    public float Damage { get; }
}
