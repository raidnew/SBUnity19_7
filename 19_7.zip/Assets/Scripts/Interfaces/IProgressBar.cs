﻿public interface IProgressBar
{
    public void SetProgress(float value);
    public void Full();
}
