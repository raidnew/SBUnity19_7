﻿public interface IExplosion
{
}

