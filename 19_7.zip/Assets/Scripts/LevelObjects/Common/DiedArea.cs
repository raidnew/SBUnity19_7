﻿using UnityEngine;

public class DiedArea : MonoBehaviour, IDiedArea
{
}
