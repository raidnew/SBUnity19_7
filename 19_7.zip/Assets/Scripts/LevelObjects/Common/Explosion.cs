using UnityEngine;

public class Explosion : MonoBehaviour, IExplosion
{
}
