﻿public interface IInputListener
{
    public void Move(float value);
    public void Run(bool isRun);
    public void Jump();
    public void Attack();
}

