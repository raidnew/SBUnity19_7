﻿public interface IPlayer
{
}

