﻿public static class Constants
{
    public readonly static string horizontal = "Horizontal";
    public readonly static string run = "Fire3";
    public readonly static string jump = "Jump";
    public readonly static string fire1 = "Fire1";
    public readonly static string fire2 = "Fire2";
}

