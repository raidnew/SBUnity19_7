﻿public interface ICanUse
{
}

