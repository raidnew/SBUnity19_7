﻿public interface IWeapon
{
    public float Damage { get; }
}

