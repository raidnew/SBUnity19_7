﻿public interface IDiedArea
{
}

