﻿public interface IAmUsable
{
    public bool CanUse { get; }
    public void Use();
}

