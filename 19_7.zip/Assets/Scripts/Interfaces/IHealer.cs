﻿public interface IHealer
{
    int Value { get; }
}

