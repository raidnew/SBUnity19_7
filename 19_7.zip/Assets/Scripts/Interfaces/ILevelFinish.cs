﻿using System;

public interface ILevelFinish
{
    public Action OnFinishComplete { get; set; }
}

