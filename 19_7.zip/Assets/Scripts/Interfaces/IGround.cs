﻿using UnityEngine;

public interface IGround
{
    public Vector2 Speed { get; }
}
