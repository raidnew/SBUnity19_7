﻿public interface IBomb
{
}

